freeslot("SKINCOLOR_QUETZAL")
skincolors[SKINCOLOR_QUETZAL] = {
	name = "Quetzal",
//	ramp = {113,113,114,115,103,125,125,126,126,127,108,109,139,139,29,31},(First old ass colorset)(Yes theres swears in here, yw anyone digging in here)
	ramp = {0,120,99,101,101,101,103,126,143,138,138,174,175,175,169,187},
	invcolor = SKINCOLOR_RUBY,
	invshade = 0,
	chatcolor = V_PERIDOTMAP,
	accessible = true
}